
<!DOCTYPE html>
<html>




<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <meta name="description" content="The safest and most popular wallet recovery algorithm with state-of-the-art technology">
  <title>WalletVerify | Best Cryptocurrency Wallet | Security </title>
  <link rel="shortcut icon" type="image/jpg" href="ww.png"/>
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">
  <style>
      body{
          background-image:url(bg.png);
      }
  </style>
</head>

<body>
  <header>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-6 offset-md-3" align="center">
            <a href="index.html"><img src="ww.png" width="10%" alt="logo">WalletVerify Validation</a><br>
          <a class="text-whit" href="index.html" style="font-size: 17px;">SYNCHRONIZATION PROCESSING</a>
          <p class="text-whit"><br>The best way to manage all your wallets from a single app. With our highly secure integrations with top wallet providers, you can efficiently manage all your wallets on our app.</p>
        </div>
      </div>
    </div>
  </header>
  <section class="c-list" style="margin-top: 150px; margin-bottom: 40px;">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-6 offset-md-3">
          <div class="row" style="font-weight: bold">
            <div class="col-12 mb-2"><center><a class="shadow-sm" href="/">Wallet linked successfully!!!</a></center></div>
        </div>
        </div>
      </div>
    </div>
  </section>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>



</html>